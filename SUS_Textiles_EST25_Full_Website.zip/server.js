import express from "express";
import helmet from "helmet";
import multer from "multer";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 10000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-this-password";
const DATA_FILE = path.join(__dirname, "data", "store.json");
const UPLOAD_DIR = path.join(__dirname, "public", "uploads");

fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 30 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image\/|video\/)/.test(file.mimetype);
    cb(ok ? null : new Error("Only image or video files are allowed."), ok);
  }
});

function readStore() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return { settings: {}, collections: [], products: [] }; }
}
function writeStore(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}
function auth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ error: "Admin login required." });
  try {
    const decoded = JSON.parse(Buffer.from(token, "base64url").toString("utf8"));
    if (!decoded.user || decoded.user !== ADMIN_USERNAME || decoded.exp < Date.now()) throw new Error();
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired admin session." });
  }
}
function makeToken() {
  return Buffer.from(JSON.stringify({
    user: ADMIN_USERNAME,
    exp: Date.now() + 8 * 60 * 60 * 1000,
    nonce: crypto.randomBytes(8).toString("hex")
  })).toString("base64url");
}

app.get("/api/store", (_req, res) => {
  const data = readStore();
  const publicData = {
    settings: data.settings,
    collections: data.collections,
    products: data.products.filter(p => p.status !== "hidden")
  };
  res.json(publicData);
});

app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD)
    return res.status(401).json({ error: "Incorrect administrator credentials." });
  res.json({ token: makeToken(), username: ADMIN_USERNAME });
});

app.get("/api/admin/store", auth, (_req, res) => res.json(readStore()));

app.post("/api/admin/product", auth, upload.single("media"), (req, res) => {
  const data = readStore();
  const b = req.body;
  if (!b.name?.trim()) return res.status(400).json({ error: "Product name is required." });
  const id = Date.now();
  let media = "";
  if (req.file) {
    const ext = path.extname(req.file.originalname) || "";
    const finalName = `${id}-${crypto.randomBytes(5).toString("hex")}${ext}`;
    const target = path.join(UPLOAD_DIR, finalName);
    fs.renameSync(req.file.path, target);
    media = `/uploads/${finalName}`;
  }
  const product = {
    id,
    name: b.name.trim(),
    code: b.code?.trim() || `SUS-${String(id).slice(-5)}`,
    collection: b.collection?.trim() || "New Collection",
    price: Number(b.price) || 0,
    discount: b.discount ? Number(b.discount) : null,
    origin: b.origin?.trim() || "Not specified",
    description: b.description?.trim() || "",
    status: b.status || "available",
    delivery: b.delivery || "Delivery fee communicated on WhatsApp",
    media
  };
  data.products.push(product);
  if (!data.collections.includes(product.collection)) data.collections.push(product.collection);
  writeStore(data);
  res.json(product);
});

app.patch("/api/admin/product/:id", auth, upload.single("media"), (req, res) => {
  const data = readStore();
  const p = data.products.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: "Product not found." });
  const b = req.body;
  for (const key of ["name","code","collection","origin","description","status","delivery"]) {
    if (b[key] !== undefined) p[key] = b[key];
  }
  if (b.price !== undefined) p.price = Number(b.price) || 0;
  if (b.discount !== undefined) p.discount = b.discount ? Number(b.discount) : null;
  if (req.file) {
    const ext = path.extname(req.file.originalname) || "";
    const finalName = `${p.id}-${crypto.randomBytes(5).toString("hex")}${ext}`;
    fs.renameSync(req.file.path, path.join(UPLOAD_DIR, finalName));
    p.media = `/uploads/${finalName}`;
  }
  if (p.collection && !data.collections.includes(p.collection)) data.collections.push(p.collection);
  writeStore(data);
  res.json(p);
});

app.delete("/api/admin/product/:id", auth, (req, res) => {
  const data = readStore();
  const idx = data.products.findIndex(x => x.id === Number(req.params.id));
  if (idx < 0) return res.status(404).json({ error: "Product not found." });
  const [removed] = data.products.splice(idx, 1);
  if (removed.media?.startsWith("/uploads/")) {
    try { fs.unlinkSync(path.join(__dirname, "public", removed.media)); } catch {}
  }
  writeStore(data);
  res.json({ ok: true });
});

app.post("/api/admin/settings", auth, (req, res) => {
  const data = readStore();
  data.settings = { ...data.settings, ...req.body };
  writeStore(data);
  res.json(data.settings);
});

app.post("/api/admin/collection", auth, (req, res) => {
  const name = String(req.body?.name || "").trim();
  if (!name) return res.status(400).json({ error: "Collection name is required." });
  const data = readStore();
  if (!data.collections.includes(name)) data.collections.push(name);
  writeStore(data);
  res.json(data.collections);
});

app.delete("/api/admin/collection/:name", auth, (req, res) => {
  const name = decodeURIComponent(req.params.name);
  const data = readStore();
  data.collections = data.collections.filter(x => x !== name);
  writeStore(data);
  res.json(data.collections);
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "SUS TEXTILES EST. 25" }));

app.get("*splat", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Request failed." });
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`SUS TEXTILES running on port ${PORT}`);
});
